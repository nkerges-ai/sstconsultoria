// ===== MOBILE MENU TOGGLE =====
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
    document.body.classList.toggle('no-scroll'); // Previne scroll do body quando menu mobile está aberto
});

// Fechar menu ao clicar em um link
const navLinks = document.querySelectorAll('.nav-link');
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
        document.body.classList.remove('no-scroll');
    });
});

// ===== FAQ ACCORDION =====
const faqQuestions = document.querySelectorAll('.faq-question');

faqQuestions.forEach(question => {
    question.addEventListener('click', () => {
        const faqItem = question.parentElement;
        
        // Fechar outros itens abertos
        document.querySelectorAll('.faq-item.active').forEach(item => {
            if (item !== faqItem) {
                item.classList.remove('active');
            }
        });
        
        // Toggle do item atual
        faqItem.classList.toggle('active');
    });
});

// ===== FORM SUBMISSION =====
const contactForm = document.getElementById('contact-form');
const formMessage = document.getElementById('form-message');

contactForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Pegar valores do formulário
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email-form').value; // Usar id diferente para evitar conflito com email do footer
    const empresa = document.getElementById('empresa').value;
    const telefone = document.getElementById('telefone-form').value;
    const servico = document.getElementById('servico').value;
    const mensagem = document.getElementById('mensagem').value;
    
    // Validação básica
    if (!nome || !email || !servico || !mensagem) {
        showMessage('Por favor, preencha todos os campos obrigatórios.', 'error');
        return;
    }
    
    // Validar email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        showMessage('Por favor, insira um email válido.', 'error');
        return;
    }
    
    // Simular envio (em produção, isso seria enviado para um servidor)
    console.log({
        nome,
        email,
        empresa,
        telefone,
        servico,
        mensagem
    });
    
    // Mostrar mensagem de sucesso
    showMessage('Mensagem enviada com sucesso! Entraremos em contato em breve.', 'success');
    
    // Limpar formulário
    contactForm.reset();
    
    // Limpar mensagem após 5 segundos
    setTimeout(() => {
        formMessage.style.display = 'none';
    }, 5000);
});

function showMessage(text, type) {
    formMessage.textContent = text;
    formMessage.className = `form-message ${type}`;
    formMessage.style.display = 'block';
}

// ===== SMOOTH SCROLL =====
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href === '#') return; // Evita scroll para o topo se o href for apenas '#'
        
        e.preventDefault();
        const target = document.querySelector(href);
        if (target) {
            const headerOffset = document.querySelector('.header').offsetHeight; // Altura do header fixo
            const elementPosition = target.getBoundingClientRect().top + window.pageYOffset;
            const offsetPosition = elementPosition - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });
        }
    });
});

// ===== ANIMAÇÃO AO SCROLL (Intersection Observer) =====
const animateElements = document.querySelectorAll('.destaque-card, .servico-card, .sobre-text, .sobre-image, .equipe-card, .depoimento-card, .blog-card, .faq-item, .contato-info, .contato-form');

const observerOptions = {
    root: null, // viewport
    rootMargin: '0px',
    threshold: 0.1 // 10% do elemento visível
};

const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target); // Para animar apenas uma vez
        }
    });
}, observerOptions);

animateElements.forEach(el => {
    el.classList.add('animate-on-scroll'); // Adiciona a classe base para animação
    observer.observe(el);
});

// ===== SCROLLSPY - DESTAQUE DO MENU ATIVO =====
window.addEventListener('scroll', () => {
    let current = '';
    const sections = document.querySelectorAll('section[id]');
    const headerHeight = document.querySelector('.header').offsetHeight;

    sections.forEach(section => {
        const sectionTop = section.offsetTop - headerHeight - 50; // Ajuste para o header e um pequeno offset
        const sectionHeight = section.clientHeight;
        if (pageYOffset >= sectionTop && pageYOffset < sectionTop + sectionHeight) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href').slice(1) === current) {
            link.classList.add('active');
        }
    });
});

// ===== WHATSAPP LINKS =====
// Os links do WhatsApp já estão diretamente no HTML com o número (11) 98678-9409
// Exemplo: <a href="https://wa.me/5511986789409" target="_blank">...</a>

// ===== VERIFICAÇÃO DE PERFORMANCE =====
console.log('Site SST Consultoria carregado com sucesso!');